package com.register;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;

@WebServlet("/registerForm")
public class Register extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ArrayList al = new ArrayList();
		String uname = request.getParameter("uname");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		
//		String uname = "";
//		String email = "";
//		String pass = "";
		
		if(uname==null || uname.equals("")) {
			al.add("Provide Name..");
		}
		if ((email == null) || (email.equals(""))) {
            al.add("PROVIDE STUDENT EMAIL...");
        }
		if ((pass == null) || (pass.equals(""))) {
            al.add("PROVIDE PASSWORD...");
        }
		
		String url = "jdbc:mysql://localhost:3306/register";
		String username = "root";
		String password = "Anandhi@6";
		
		PrintWriter out = response.getWriter();
		
		if (al.size() != 0) {
			response.setContentType("text/html");
			HttpSession session = request.getSession();
			session.setAttribute("Name", al.toString().indexOf(0));
			session.setAttribute("Email", al.indexOf(1));
			session.setAttribute("Pass", al.indexOf(2));
			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
			rd.include(request, response);
//            out.println(al);
        } else {
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			
			PreparedStatement ps = con.prepareStatement("insert into register values(?,?,?)");
			ps.setString(1, uname);
			ps.setString(2, email);
			ps.setString(3, pass);
			
			int result = ps.executeUpdate();
//			out.println("<br>");;
			if(result>0) {
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.include(request, response);
				out.println("<h3 style='color:green'>Registered Successfully Thank You!</h3>");
			}else{
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.include(request, response);
				out.println("<h3 style='color:red'>Registration Failed</h3>");
			}
			
		 }catch(Exception e) {
			response.setContentType("text/html");
			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
			rd.include(request, response);
			out.println("<h3 style=color:red'>Registration Failed Please Try Again!</h3>");
		 }
        }
	}

}
