package com.register;

import java.io.*;
import java.sql.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/loginForm")
public class Login extends HttpServlet{
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		String email = req.getParameter("email");
		String pass = req.getParameter("pass");
		
		String url = "jdbc:mysql://localhost:3306/register";
		String username = "root";
		String password = "Anandhi@6";
		PrintWriter out = res.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement ps = con.prepareStatement("select * from register where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, pass);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				
				res.setContentType("text/html");
				HttpSession session = req.getSession();
				session.setAttribute("session", rs.getString("name"));
				RequestDispatcher rd = req.getRequestDispatcher("/profile.jsp");
				rd.include(req, res);
			}else {
				res.setContentType("text/html");
				RequestDispatcher rd = req.getRequestDispatcher("/login.jsp");
				rd.include(req, res);
				out.println("<h3 style='color:red'>Incorrect email or password</h3>");
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
